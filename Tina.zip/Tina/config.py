SECRET_KEY = 'this-is-a-secret-key'
SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'

GOOGLE_CLIENT_ID = '893100767350-t9vomhndqheno3p5hdi16kbicquvkv1a.apps.googleusercontent.com'
GOOGLE_CLIENT_SECRET = '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'